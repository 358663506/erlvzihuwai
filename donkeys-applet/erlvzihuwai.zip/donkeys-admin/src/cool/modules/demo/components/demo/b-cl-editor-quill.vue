<template>
	<div class="scope">
		<div class="h">
			<span>cl-editor-quill</span>
			Quill 富文本编辑器
		</div>
		<div class="c">
			<router-link to="/editor-quill">传送门</router-link>
		</div>
		<div class="f">
			<span class="date">2019/11/07</span>
		</div>
	</div>
</template>
