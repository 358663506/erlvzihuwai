import { checkPerm } from "./directives/permission";
import { iconList } from "./common";
import "./static/css/index.scss";

export { iconList, checkPerm };
