import { iconList } from "./theme";
import "./resize";

export { iconList };
