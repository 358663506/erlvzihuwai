module.exports = {
    env: {
        node: true,
        'vue/setup-compiler-macros': true
    },
    extends: ['plugin:@typescript-eslint/recommended', 'eslint:recommended', 'plugin:vue/vue3-recommended', 'prettier'],
    rules: {
        'vue/script-setup-uses-vars': 'error',
        // override/add rules settings here, such as:
        // 'vue/no-unused-vars': 'error'
        'no-unused-vars': 'off',
        '@typescript-eslint/no-unused-vars': ['error']
    },
    parser: 'vue-eslint-parser',
    parserOptions: {
        parser: {
            // Script parser for `<script>`
            js: 'espree',

            // Script parser for `<script lang="ts">`
            ts: '@typescript-eslint/parser',

            // Script parser for vue directives (e.g. `v-if=` or `:attribute=`)
            // and vue interpolations (e.g. `{{variable}}`).
            // If not specified, the parser determined by `<script lang ="...">` is used.
            '<template>': 'espree'
        }
    }
};
