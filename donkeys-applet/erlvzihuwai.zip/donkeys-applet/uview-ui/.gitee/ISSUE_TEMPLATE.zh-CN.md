## bug所属区域（vue页面，nvue页面，文档）


## 简单描述


## 问题截图


## 代码示例


## uView版本号


## 测试平台（h5，android，ios，微信小程序，其他小程序）


## 备注



或者使用下面的链接创建 issue 以帮助我们更快的排查问题，不规范的 issue 会被关闭，感谢配合。

https://new-issue.uviewui.com/
