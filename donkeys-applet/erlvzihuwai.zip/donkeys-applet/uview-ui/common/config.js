module.exports = {
    baseUrl: 'https://api.youzixy.com'
}
