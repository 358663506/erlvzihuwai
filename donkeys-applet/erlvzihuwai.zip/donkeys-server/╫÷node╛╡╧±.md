docker run --name centeros -it centos:latest /bin/bash
// 安装环境
cd /etc/yum.repos.d/
sed -i 's/mirrorlist/#mirrorlist/g' /etc/yum.repos.d/CentOS-_
sed -i 's|#baseurl=http://mirror.centos.org|baseurl=http://vault.centos.org|g' /etc/yum.repos.d/CentOS-_
yum update -y
// 安装 node
curl --silent --location https://rpm.nodesource.com/setup_16.x | bash
sudo yum -y install nodejs
npm install -g npm@8.6.0
// 退出
exit

docker commit <container 的 ID> <新的 image_name>
docker commit centeros node-npm-86

# docker 部署

# damin-dockerfile

```
FROM node-npm-86
WORKDIR /build
# 设置Node-Sass的镜像地址
RUN npm config set sass_binary_site https://npm.taobao.org/mirrors/node-sass/
# 设置npm镜像
COPY package.json /build/package.json
RUN npm install --force
COPY ./ /build
RUN npm run build
FROM nginx
RUN mkdir /app
COPY --from=0 /build/dist /app
COPY --from=0 /build/nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
```

# server-dockerfile

```
FROM node-npm-86

WORKDIR /app

# 配置alpine国内镜像加速
# RUN sed -i "s@http://dl-cdn.alpinelinux.org/@https://repo.huaweicloud.com/@g" /etc/apk/repositories

# 安装tzdata,默认的alpine基础镜像不包含时区组件，安装后可通过TZ环境变量配置时区
# RUN apk add --no-cache tzdata

# 设置时区为中国东八区，这里的配置可以被docker-compose.yml或docker run时指定的时区覆盖
ENV TZ="Asia/Shanghai"

# 如果各公司有自己的私有源，可以替换registry地址,如使用官方源注释下一行
RUN npm config set registry https://registry.npm.taobao.org

# 安装开发期依赖
COPY package.json ./package.json
RUN npm install
# 构建项目
COPY . .
RUN npm run build
# 删除开发期依赖
RUN rm -rf node_modules && rm package-lock.json
# 安装生产环境依赖
RUN npm install --production

# 如果端口更换，这边可以更新一下
EXPOSE 8001

CMD ["npm", "run", "docker"]
```

# 制作镜像

docker build -t web-admin .
docker build -t node-server .

# 启动容器

docker run -p 8080:80 --name web-admin -d web-admin
docker run -p 8001:8001 --name node-server -d node-server
