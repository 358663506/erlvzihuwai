import { Provide } from '@midwayjs/decorator';
import { BaseService } from '@cool-midway/core';

/** 轮播图 */
@Provide()
export class AppletsCarouselService extends BaseService {}
