import { Provide } from '@midwayjs/decorator';
import { BaseService } from '@cool-midway/core';

/* 消息推送 */
@Provide()
export class AppletsMessageService extends BaseService {}
