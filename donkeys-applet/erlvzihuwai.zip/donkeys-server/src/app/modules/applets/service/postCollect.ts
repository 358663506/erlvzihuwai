import { Provide } from '@midwayjs/decorator';
import { BaseService } from '@cool-midway/core';

/* 收藏 */
@Provide()
export class AppletsPostColletService extends BaseService {}
